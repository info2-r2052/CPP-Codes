
#include <iostream>
#include "Persona.h"

using std::cout;
using std::cin;
using std::endl;

Persona::Persona(){
    // Contructor
    nombre = "NN";
}

Persona::Persona(const Persona &p){
    legajo = p.legajo;
    dni = p.dni;
    nombre = p.nombre;
}

Persona::Persona(int leg, int _dni, std::string name){
    // Contructor
    legajo = leg;
    dni = _dni;
    nombre = name;
}

Persona::Persona(std::string name){
    // Contructor
    nombre = name;
}

Persona::~Persona(){
    //Destructor
    cout << "Destructor " << nombre << endl;
}

void Persona::Imprimir(void){
    cout << "Leg: " << legajo << " Dni: " << dni << " Nombre: " << nombre << endl;
}

void Persona::Cargar(int leg, int _dni, std::string name){
    legajo = leg;
    dni = _dni;
    nombre = name;
}

int Persona::SetLegajo(int leg){
    if(leg < 0 || leg > 1000000){
        cout << "Error" << endl;
        return -1;
    }

    legajo = leg;
    return 0;
}

void Persona::SetDni(int DNI){
    dni = DNI;
}

int Persona::GetDni(void){
    return dni;
}



