#include <iostream>
#include "Persona.h"

using std::cout;
using std::cin;
using std::endl;

Persona Pedro(1, 1, "Pedro"), Juan;

Persona Alumno(Pedro);

Persona *Alumno2;

int main(void)
{
    cout << "Init" << endl;

    Alumno2 = new Persona(1,1,"Pedro");

    Alumno2->Imprimir();

    Juan.SetLegajo(123);

    Juan.Imprimir();

    return -1;
}