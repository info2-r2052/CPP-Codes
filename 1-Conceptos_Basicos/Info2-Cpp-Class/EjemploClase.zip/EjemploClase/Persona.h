#include <iostream>

class Persona
{
    private:
        int legajo;
        int dni;
        std::string nombre;

    public:
        Persona();

        Persona(const Persona &p);

        Persona(int leg, int _dni, std::string name);

        Persona(std::string name);

        ~Persona();

        void Imprimir(void);

        void Cargar(int leg, int _dni, std::string name);

        int SetLegajo(int leg);

        void SetDni(int DNI);

        int GetDni(void);
};
